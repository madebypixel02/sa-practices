package edu.uoc.epcsd.notification.domain.service;

import edu.uoc.epcsd.notification.application.kafka.MicrocredentialMessage;
import edu.uoc.epcsd.notification.application.kafka.ProductMessage;
import edu.uoc.epcsd.notification.application.rest.dtos.GetProductResponse;
import edu.uoc.epcsd.notification.application.rest.dtos.GetUserResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.time.LocalDate;

@Log4j2
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
public class NotificationServiceImpl implements NotificationService {

    private final RestTemplate restTemplate;

    @Value("${usersService.getUsersToAlert.url}")
    private String userToAlertUrl;

    @Value("${usersService.url}")
    private String usersServiceUrl;

    @Value("${productService.getProductDetails.url}")
    private String productServiceUrl;

    @Override
    public void notifyProductAvailable(ProductMessage productMessage) {
        GetProductResponse product = restTemplate.getForEntity(productServiceUrl, GetProductResponse.class, productMessage.getProductId()).getBody();

        GetUserResponse[] usersToAlert = restTemplate.getForEntity(userToAlertUrl, GetUserResponse[].class, productMessage.getProductId(), LocalDate.now()).getBody();

        if (usersToAlert == null) return;

        for (GetUserResponse user : usersToAlert) {
            log.info("User {} ({}) has been notified by email that a unit of product {} is available.",
                    user.getFullName(), user.getEmail(), product.getName());
        }
    }

    @Override
    public void notifyCredentialPending(MicrocredentialMessage microcredentialMessage) {
        GetUserResponse[] allUsers = restTemplate.getForEntity(usersServiceUrl, GetUserResponse[].class).getBody();

        if (allUsers == null) return;

        for (GetUserResponse user : allUsers) {
            if ("ADMIN".equals(user.getType())) {
                log.info("Admin {} ({}) has been notified by email that microcredential {} for enrollment {} is pending aproval.",
                        user.getFullName(), user.getEmail(),
                        microcredentialMessage.getMicrocredentialId(), microcredentialMessage.getEnrollment());
            }
        }
    }

    @Override
    public void notifyCredentialGranted(MicrocredentialMessage microcredentialMessage) {
        GetUserResponse user = restTemplate.getForEntity(
                usersServiceUrl + "/byEmail/{email}", GetUserResponse.class, microcredentialMessage.getUserEmail()).getBody();

        if (user == null) return;

        log.info("Student {} ({}) has been notified by email that microcredential {} has been granted.",
                user.getFullName(), user.getEmail(), microcredentialMessage.getMicrocredentialId());
    }

    @Override
    public void notifyCredentialRejected(MicrocredentialMessage microcredentialMessage) {
        GetUserResponse user = restTemplate.getForEntity(
                usersServiceUrl + "/byEmail/{email}", GetUserResponse.class, microcredentialMessage.getUserEmail()).getBody();

        if (user == null) return;

        log.info("Student {} ({}) has been notified by email that microcredential {} has been rejected.",
                user.getFullName(), user.getEmail(), microcredentialMessage.getMicrocredentialId());
    }

}
