package edu.uoc.epcsd.course.domain.service;

import edu.uoc.epcsd.course.domain.Enrollment;
import edu.uoc.epcsd.course.domain.EnrollmentStatus;
import edu.uoc.epcsd.course.domain.repository.CourseRepository;
import edu.uoc.epcsd.course.domain.repository.EnrollmentRepository;
import edu.uoc.epcsd.course.domain.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final CourseRepository courseRepository;
    private final UserRepository userRepository;

    @Override
    public List<Enrollment> getEnrollmentsByCourse(Long courseId) {
        return enrollmentRepository.findEnrollmentByCourse(courseId);
    }

    @Override
    public List<Enrollment> getEnrolledStudents(Long courseId) {
        return enrollmentRepository.findEnrollmentByCourse(courseId).stream()
                .filter(e -> e.getStatus() == EnrollmentStatus.ACTIVE || e.getStatus() == EnrollmentStatus.GRADED)
                .collect(Collectors.toList());
    }

    @Override
    public Long enrollInCourse(Long courseId, String studentEmail) {
        courseRepository.getCourseById(courseId).orElseThrow(() -> new IllegalArgumentException("Course " + courseId + " does not exist"));
        if (!userRepository.findUserByEmail(studentEmail)) {
            throw new IllegalArgumentException("User " + studentEmail + " does not exsit");
        }
        Enrollment enrollment = Enrollment.builder()
                .student(studentEmail)
                .enrollmentDate(new Date())
                .qualification(0L)
                .status(EnrollmentStatus.ACTIVE)
                .courseId(courseId)
                .build();
        return enrollmentRepository.createEnrollment(enrollment);
    }

    @Override
    public void closeGradeReports(Long courseId) {
        List<Enrollment> enrollments = enrollmentRepository.findEnrollmentByCourse(courseId);
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getQualification() != null && enrollment.getQualification() > 0) {
                enrollment.setStatus(EnrollmentStatus.GRADED);
                enrollmentRepository.updateEnrollment(enrollment);
            }
        }
    }

}
