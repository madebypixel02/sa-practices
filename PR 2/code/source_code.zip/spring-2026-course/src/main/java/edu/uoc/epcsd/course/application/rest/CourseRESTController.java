package edu.uoc.epcsd.course.application.rest;

import edu.uoc.epcsd.course.application.rest.request.CourseRequest;
import edu.uoc.epcsd.course.domain.Course;
import edu.uoc.epcsd.course.domain.Enrollment;
import edu.uoc.epcsd.course.domain.service.CourseService;
import edu.uoc.epcsd.course.domain.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.net.URI;
import java.util.Date;
import java.util.List;

@Log4j2
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController
@RequestMapping("/courses")
public class CourseRESTController {

    private final CourseService courseService;
    private final EnrollmentService enrollmentService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Course> findCourses(@RequestParam(required = false) String title,
                                    @RequestParam(required = false) String instructor) {
        log.trace("findCourses");
        return courseService.findCourses(Course.builder().title(title).instructor(instructor).build());
    }

    @GetMapping("/{courseId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Course> getCourseById(@PathVariable @NotNull Long courseId) {
        log.trace("getCourseById");
        try {
            return courseService.getCourseById(courseId)
                    .map(ResponseEntity::ok)
                    .orElse(ResponseEntity.notFound().build());
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }

    @PostMapping
    public ResponseEntity<Long> createCourse(@RequestBody @NotNull @Valid CourseRequest courseRequest) {
        log.trace("createCourse");
        try {
            Long id = courseService.createCourse(Course.builder()
                    .instructor(courseRequest.getInstructor())
                    .title(courseRequest.getTitle())
                    .description(courseRequest.getDescription())
                    .enrollmentStartDate(courseRequest.getEnrollmentStartDate())
                    .enrollmentEndDate(courseRequest.getEnrollmentEndDate())
                    .mode(courseRequest.getMode())
                    .price(courseRequest.getPrice())
                    .objectives(courseRequest.getObjectives())
                    .methology(courseRequest.getMethology())
                    .duration(courseRequest.getDuration())
                    .language(courseRequest.getLanguage())
                    .location(courseRequest.getLocation())
                    .build());
            URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(id).toUri();
            return ResponseEntity.created(uri).body(id);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    @PutMapping("/{courseId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Long> modifyCourseDetails(@PathVariable @NotNull Long courseId,
                                                     @RequestBody @NotNull @Valid CourseRequest courseRequest) {
        log.trace("modifyCourseDetails");
        try {
            Long id = courseService.modifyCourseDetails(Course.builder()
                    .id(courseId)
                    .instructor(courseRequest.getInstructor())
                    .title(courseRequest.getTitle())
                    .description(courseRequest.getDescription())
                    .enrollmentStartDate(courseRequest.getEnrollmentStartDate())
                    .enrollmentEndDate(courseRequest.getEnrollmentEndDate())
                    .mode(courseRequest.getMode())
                    .price(courseRequest.getPrice())
                    .objectives(courseRequest.getObjectives())
                    .methology(courseRequest.getMethology())
                    .duration(courseRequest.getDuration())
                    .language(courseRequest.getLanguage())
                    .location(courseRequest.getLocation())
                    .build());
            return ResponseEntity.ok(id);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    @PatchMapping("/{courseId}/enrollment/open")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Void> openEnrollment(@PathVariable @NotNull Long courseId,
                                               @RequestParam @NotNull @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
                                               @RequestParam @NotNull @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
        log.trace("openEnrollment");
        try {
            courseService.openEnrollment(courseId, startDate, endDate);
            return ResponseEntity.ok().build();
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    @PatchMapping("/{courseId}/enrollment/close")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Void> closeEnrollment(@PathVariable @NotNull Long courseId) {
        log.trace("closeEnrollment");
        try {
            courseService.closeEnrollment(courseId);
            return ResponseEntity.ok().build();
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    @GetMapping("/{courseId}/enrollments")
    @ResponseStatus(HttpStatus.OK)
    public List<Enrollment> getEnrollmentsByCourse(@PathVariable @NotNull Long courseId) {
        log.trace("getEnrollmentsByCourse");
        return courseService.getEnrollmentsByCourse(courseId);
    }

    @PostMapping("/{courseId}/enrollments")
    public ResponseEntity<Long> enrollInCourse(@PathVariable @NotNull Long courseId,
                                               @RequestParam @NotNull String email) {
        log.trace("enrollInCourse");
        try {
            Long id = enrollmentService.enrollInCourse(courseId, email);
            URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(id).toUri();
            return ResponseEntity.created(uri).body(id);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    @GetMapping("/{courseId}/students")
    @ResponseStatus(HttpStatus.OK)
    public List<Enrollment> getEnrolledStudents(@PathVariable @NotNull Long courseId) {
        log.trace("getEnrolledStudents");
        return courseService.getEnrolledStudents(courseId);
    }

    @PatchMapping("/{courseId}/grade-reports/close")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Void> closeGradeReports(@PathVariable @NotNull Long courseId) {
        log.trace("closeGradeReports");
        try {
            courseService.closeGradeReports(courseId);
            return ResponseEntity.ok().build();
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    @PatchMapping("/{courseId}/close")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Void> closeCourse(@PathVariable @NotNull Long courseId) {
        log.trace("closeCourse");
        try {
            courseService.closeCourse(courseId);
            return ResponseEntity.ok().build();
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

}
