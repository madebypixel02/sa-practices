package edu.uoc.epcsd.course.domain.repository;

import edu.uoc.epcsd.course.domain.Course;

import java.util.List;
import java.util.Optional;

public interface CourseRepository {

    Optional<Course> getCourseById(Long courseId);

    List<Course> findAllCourses();

    List<Course> findCoursesByExample(Course course);

    Long createCourse(Course course);

    Long modifyCourseDetails(Course course);

    Long openEnrollment(Course course);

    Long closeEnrollment(Course course);

    Long closeCourse(Course course);

}
