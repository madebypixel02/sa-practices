package edu.uoc.epcsd.course.domain.service;

import edu.uoc.epcsd.course.domain.Course;
import edu.uoc.epcsd.course.domain.Enrollment;
import edu.uoc.epcsd.course.domain.repository.CourseRepository;
import edu.uoc.epcsd.course.domain.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Log4j2
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;
    private final UserRepository userRepository;
    private final EnrollmentService enrollmentService;
    private final RestTemplate restTemplate;

    @Value("${credentialService.create.url}")
    private String microcredentialServiceUrl;

    @Override
    public Optional<Course> getCourseById(Long courseId) {
        return Optional.of(courseRepository.getCourseById(courseId).orElseThrow(() -> new IllegalArgumentException("Course " + courseId + " does not exist")));
    }

    @Override
    public List<Course> findCourses(Course course) {
        return courseRepository.findCoursesByExample(course);
    }

    @Override
    public Long createCourse(Course course) {
        if (!userRepository.findInstructorByEmail(course.getInstructor())) {
            throw new IllegalArgumentException("Instructor " + course.getInstructor() + " does not exist");
        }
        return courseRepository.createCourse(course);
    }

    @Override
    public Long modifyCourseDetails(Course course) {
        courseRepository.getCourseById(course.getId()).orElseThrow(() -> new IllegalArgumentException("Course " + course.getId() + " does not exist"));
        return courseRepository.modifyCourseDetails(course);
    }

    @Override
    public Long openEnrollment(Long courseId, Date startDate, Date endDate) {
        Course course = courseRepository.getCourseById(courseId).orElseThrow(() -> new IllegalArgumentException("Course " + courseId + " does not exist"));
        course.setEnrollmentStartDate(startDate);
        course.setEnrollmentEndDate(endDate);
        return courseRepository.openEnrollment(course);
    }

    @Override
    public Long closeEnrollment(Long courseId) {
        Course course = courseRepository.getCourseById(courseId).orElseThrow(() -> new IllegalArgumentException("Course " + courseId + " does not exist"));
        return courseRepository.closeEnrollment(course);
    }

    @Override
    public Long closeGradeReports(Long courseId) {
        courseRepository.getCourseById(courseId).orElseThrow(() -> new IllegalArgumentException("Course " + courseId + " does not exist"));
        enrollmentService.closeGradeReports(courseId);
        log.info("Requesting microcredentails for course {}", courseId);
        restTemplate.postForEntity(microcredentialServiceUrl, null, Void.class, courseId);
        return courseId;
    }

    @Override
    public Long closeCourse(Long courseId) {
        Course course = courseRepository.getCourseById(courseId).orElseThrow(() -> new IllegalArgumentException("Course " + courseId + " does not exist"));
        return courseRepository.closeCourse(course);
    }

    @Override
    public List<Enrollment> getEnrollmentsByCourse(Long courseId) {
        return enrollmentService.getEnrollmentsByCourse(courseId);
    }

    @Override
    public List<Enrollment> getEnrolledStudents(Long courseId) {
        return enrollmentService.getEnrolledStudents(courseId);
    }

}
