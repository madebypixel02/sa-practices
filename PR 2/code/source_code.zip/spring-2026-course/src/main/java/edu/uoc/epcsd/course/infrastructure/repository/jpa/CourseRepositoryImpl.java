package edu.uoc.epcsd.course.infrastructure.repository.jpa;

import edu.uoc.epcsd.course.domain.Course;
import edu.uoc.epcsd.course.domain.CourseStatus;
import edu.uoc.epcsd.course.domain.repository.CourseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class CourseRepositoryImpl implements CourseRepository {

    private final SpringDataCourseRepository jpaCourseRepository;

    @Override
    public Optional<Course> getCourseById(Long courseId) {
        return jpaCourseRepository.getCourseById(courseId).map(CourseEntity::toDomain);
    }

    @Override
    public List<Course> findAllCourses() {
        return jpaCourseRepository.findAll().stream().map(CourseEntity::toDomain).collect(Collectors.toList());
    }

    @Override
    public List<Course> findCoursesByExample(Course course) {
        ExampleMatcher matcher = ExampleMatcher.matching()
                .withIgnorePaths("status")
                .withMatcher("title", ExampleMatcher.GenericPropertyMatchers.contains().ignoreCase())
                .withMatcher("instructor", ExampleMatcher.GenericPropertyMatchers.contains().ignoreCase());
        Example<CourseEntity> example = Example.of(CourseEntity.fromDomain(course), matcher);
        return jpaCourseRepository.findAll(example).stream().map(CourseEntity::toDomain).collect(Collectors.toList());
    }

    @Override
    public Long createCourse(Course course) {
        return jpaCourseRepository.save(CourseEntity.fromDomain(course)).getId();
    }

    @Override
    public Long modifyCourseDetails(Course course) {
        CourseEntity entity = jpaCourseRepository.findById(course.getId()).orElseThrow(IllegalArgumentException::new);
        entity.setTitle(course.getTitle());
        entity.setDescription(course.getDescription());
        entity.setMode(course.getMode());
        entity.setObjectives(course.getObjectives());
        entity.setMethology(course.getMethology());
        entity.setDuration(course.getDuration());
        entity.setLanguage(course.getLanguage());
        entity.setLocation(course.getLocation());
        entity.setPrice(course.getPrice());
        return jpaCourseRepository.save(entity).getId();
    }

    @Override
    public Long openEnrollment(Course course) {
        CourseEntity entity = jpaCourseRepository.findById(course.getId()).orElseThrow(IllegalArgumentException::new);
        entity.setEnrollmentStartDate(course.getEnrollmentStartDate());
        entity.setEnrollmentEndDate(course.getEnrollmentEndDate());
        entity.setStatus(CourseStatus.ENROLLMENT_OPEN);
        return jpaCourseRepository.save(entity).getId();
    }

    @Override
    public Long closeEnrollment(Course course) {
        CourseEntity entity = jpaCourseRepository.findById(course.getId()).orElseThrow(IllegalArgumentException::new);
        entity.setStatus(CourseStatus.ACTIVE);
        return jpaCourseRepository.save(entity).getId();
    }

    @Override
    public Long closeCourse(Course course) {
        CourseEntity entity = jpaCourseRepository.findById(course.getId()).orElseThrow(IllegalArgumentException::new);
        entity.setStatus(CourseStatus.CLOSED);
        return jpaCourseRepository.save(entity).getId();
    }

}
