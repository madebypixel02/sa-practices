package edu.uoc.epcsd.course.domain.service;

import edu.uoc.epcsd.course.domain.Course;
import edu.uoc.epcsd.course.domain.Enrollment;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface CourseService {

    Optional<Course> getCourseById(Long courseId);

    List<Course> findCourses(Course course);

    Long createCourse(Course course);

    Long modifyCourseDetails(Course course);

    Long openEnrollment(Long courseId, Date startDate, Date endDate);

    Long closeEnrollment(Long courseId);

    Long closeGradeReports(Long courseId);

    Long closeCourse(Long courseId);

    List<Enrollment> getEnrollmentsByCourse(Long courseId);

    List<Enrollment> getEnrolledStudents(Long courseId);

}
