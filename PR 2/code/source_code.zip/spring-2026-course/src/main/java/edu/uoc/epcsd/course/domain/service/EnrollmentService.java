package edu.uoc.epcsd.course.domain.service;

import edu.uoc.epcsd.course.domain.Enrollment;

import java.util.List;

public interface EnrollmentService {

    List<Enrollment> getEnrollmentsByCourse(Long courseId);

    List<Enrollment> getEnrolledStudents(Long courseId);

    Long enrollInCourse(Long courseId, String studentEmail);

    void closeGradeReports(Long courseId);

}
