package edu.uoc.epcsd.microcredential.domain.service;

import edu.uoc.epcsd.microcredential.domain.Microcredential;
import edu.uoc.epcsd.microcredential.domain.MicrocredentialStatus;
import edu.uoc.epcsd.microcredential.domain.repository.MicrocredentialRepository;
import edu.uoc.epcsd.microcredential.infrastructure.kafka.KafkaConstants;
import edu.uoc.epcsd.microcredential.infrastructure.kafka.MicrocredentialMessage;
import edu.uoc.epcsd.microcredential.infrastructure.repository.rest.GetEnrollmentResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.client.RestTemplate;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Log4j2
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
@Validated
public class MicrocredentialServiceImpl implements MicrocredentialService {

    private final MicrocredentialRepository microcredentialRepository;
    private final KafkaTemplate<String, MicrocredentialMessage> microcredentialKafkaTemplate;
    private final RestTemplate restTemplate;

    @Value("${courseService.url}")
    private String courseServiceUrl;

    @Override
    public Optional<Microcredential> getMicrocredentialById(@NotNull Long microcredentialId) {
        return microcredentialRepository.getMicrocredentialById(microcredentialId);
    }

    @Override
    public Long requestMicrocredential(Long enrollmentId, Long courseId, String content) {
        Microcredential microcredential = Microcredential.builder()
                .submitDate(new Date())
                .assignmentDate(new Date())
                .status(MicrocredentialStatus.REQUESTED)
                .content(content)
                .enrollment(enrollmentId)
                .courseId(courseId)
                .build();

        Long id = microcredentialRepository.createMicrocredential(microcredential);

        GetEnrollmentResponse[] enrollments = restTemplate.getForObject(
                courseServiceUrl + "/{courseId}/enrollments", GetEnrollmentResponse[].class, courseId);

        String studentEmail = null;
        if (enrollments != null) {
            studentEmail = Arrays.stream(enrollments)
                    .filter(e -> e.getId().equals(enrollmentId))
                    .map(GetEnrollmentResponse::getStudent)
                    .findFirst()
                    .orElse(null);
        }

        microcredentialKafkaTemplate.send(
                KafkaConstants.MICROCREDENTIAL_TOPIC + KafkaConstants.SEPARATOR + KafkaConstants.PENDING,
                MicrocredentialMessage.builder()
                        .microcredentialId(id)
                        .userEmail(studentEmail)
                        .courseId(courseId)
                        .enrollment(enrollmentId)
                        .build());

        log.info("Microcredential {} requested for enrollment {} in course {}", id, enrollmentId, courseId);
        return id;
    }

    @Override
    public List<Long> requestCourseMicrocredentials(Long courseId) {
        GetEnrollmentResponse[] enrollments = restTemplate.getForObject(
                courseServiceUrl + "/{courseId}/enrollments", GetEnrollmentResponse[].class, courseId);

        if (enrollments == null) {
            throw new IllegalArgumentException("Could not fetch enrollments for course " + courseId);
        }

        List<Long> ids = new ArrayList<>();
        for (GetEnrollmentResponse enrollment : enrollments) {
            if (!"GRADED".equals(enrollment.getStatus())) {
                continue;
            }
            Microcredential microcredential = Microcredential.builder()
                    .submitDate(new Date())
                    .assignmentDate(new Date())
                    .status(MicrocredentialStatus.REQUESTED)
                    .content("Microcredential for enrolment " + enrollment.getId() + " in course " + courseId)
                    .enrollment(enrollment.getId())
                    .courseId(courseId)
                    .build();

            Long id = microcredentialRepository.createMicrocredential(microcredential);
            ids.add(id);

            microcredentialKafkaTemplate.send(
                    KafkaConstants.MICROCREDENTIAL_TOPIC + KafkaConstants.SEPARATOR + KafkaConstants.PENDING,
                    MicrocredentialMessage.builder()
                            .microcredentialId(id)
                            .userEmail(enrollment.getStudent())
                            .courseId(courseId)
                            .enrollment(enrollment.getId())
                            .build());

            log.info("Microcredential {} requested for enrollment {} in course {}", id, enrollment.getId(), courseId);
        }

        return ids;
    }

    @Override
    public Long approvePendingMicrocredential(Long microcredentialId) {
        Microcredential microcredential = microcredentialRepository.getMicrocredentialById(microcredentialId)
                .orElseThrow(() -> new IllegalArgumentException("Microcredential " + microcredentialId + " does not exist"));

        if (microcredential.getStatus() != MicrocredentialStatus.REQUESTED) {
            throw new IllegalArgumentException("Microcredential " + microcredentialId + " is not in REQUESTED stauts");
        }

        String userEmail = getStudentEmailForMicrocredential(microcredential);

        microcredential.setStatus(MicrocredentialStatus.GRANTED);
        microcredential.setAssignmentDate(new Date());
        Long id = microcredentialRepository.updateMicrocredential(microcredential);

        microcredentialKafkaTemplate.send(
                KafkaConstants.MICROCREDENTIAL_TOPIC + KafkaConstants.SEPARATOR + KafkaConstants.APPROVED,
                MicrocredentialMessage.builder()
                        .microcredentialId(id)
                        .userEmail(userEmail)
                        .enrollment(microcredential.getEnrollment())
                        .build());

        log.info("Microcredential {} approved", id);
        return id;
    }

    @Override
    public Long rejectPendingMicrocredential(Long microcredentialId) {
        Microcredential microcredential = microcredentialRepository.getMicrocredentialById(microcredentialId)
                .orElseThrow(() -> new IllegalArgumentException("Microcredential " + microcredentialId + " does not exist"));

        if (microcredential.getStatus() != MicrocredentialStatus.REQUESTED) {
            throw new IllegalArgumentException("Microcredential " + microcredentialId + " is not in REQUESTED status");
        }

        String userEmail = getStudentEmailForMicrocredential(microcredential);

        microcredential.setStatus(MicrocredentialStatus.REJECTED);
        microcredential.setAssignmentDate(new Date());
        Long id = microcredentialRepository.updateMicrocredential(microcredential);

        microcredentialKafkaTemplate.send(
                KafkaConstants.MICROCREDENTIAL_TOPIC + KafkaConstants.SEPARATOR + KafkaConstants.REJECTED,
                MicrocredentialMessage.builder()
                        .microcredentialId(id)
                        .userEmail(userEmail)
                        .enrollment(microcredential.getEnrollment())
                        .build());

        log.info("Microcredential {} rejected", id);
        return id;
    }

    @Override
    public List<Microcredential> getPendingMicrocredentialRequests() {
        return microcredentialRepository.getPendingMicrocredentialRequests();
    }

    private String getStudentEmailForMicrocredential(Microcredential microcredential) {
        GetEnrollmentResponse[] enrollments = restTemplate.getForObject(
                courseServiceUrl + "/{courseId}/enrollments", GetEnrollmentResponse[].class, microcredential.getCourseId());

        if (enrollments == null) {
            throw new IllegalStateException("Could not fetch enrollments for course " + microcredential.getCourseId());
        }

        return Arrays.stream(enrollments)
                .filter(e -> e.getId().equals(microcredential.getEnrollment()))
                .map(GetEnrollmentResponse::getStudent)
                .findFirst()
                .orElseThrow(() -> new IllegalStateException("Enrollment " + microcredential.getEnrollment() + " not found in course " + microcredential.getCourseId()));
    }

}
