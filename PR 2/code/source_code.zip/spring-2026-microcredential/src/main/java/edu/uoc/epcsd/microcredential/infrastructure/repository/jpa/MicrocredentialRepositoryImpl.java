package edu.uoc.epcsd.microcredential.infrastructure.repository.jpa;

import edu.uoc.epcsd.microcredential.domain.Microcredential;
import edu.uoc.epcsd.microcredential.domain.MicrocredentialStatus;
import edu.uoc.epcsd.microcredential.domain.repository.MicrocredentialRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class MicrocredentialRepositoryImpl implements MicrocredentialRepository {

    private final SpringDataMicrocredentialRepository jpaMicrocredentialRepository;

    @Override
    public Optional<Microcredential> getMicrocredentialById(Long microcredentialId) {
        return jpaMicrocredentialRepository.getMicrocredentialById(microcredentialId).map(MicrocredentialEntity::toDomain);
    }

    @Override
    public Long createMicrocredential(Microcredential microcredential) {
        return jpaMicrocredentialRepository.save(MicrocredentialEntity.fromDomain(microcredential)).getId();
    }

    @Override
    public Long updateMicrocredential(Microcredential microcredential) {
        MicrocredentialEntity entity = jpaMicrocredentialRepository.findById(microcredential.getId()).orElseThrow(IllegalArgumentException::new);
        entity.setStatus(microcredential.getStatus());
        entity.setAssignmentDate(microcredential.getAssignmentDate());
        return jpaMicrocredentialRepository.save(entity).getId();
    }

    @Override
    public List<Microcredential> getPendingMicrocredentialRequests() {
        return jpaMicrocredentialRepository.findByStatus(MicrocredentialStatus.REQUESTED).stream()
                .map(MicrocredentialEntity::toDomain)
                .collect(Collectors.toList());
    }

}
