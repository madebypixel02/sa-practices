package edu.uoc.epcsd.microcredential.infrastructure.repository.rest;

import lombok.*;

import java.util.Date;

@ToString
@Getter
@Setter
@EqualsAndHashCode
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GetEnrollmentResponse {

    private Long id;
    private String student;
    private Date enrollmentDate;
    private Long qualification;
    private String status;
    private Long courseId;

}
