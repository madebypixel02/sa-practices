package edu.uoc.epcsd.microcredential.application.rest;

import edu.uoc.epcsd.microcredential.application.rest.request.MicrocredentialRequest;
import edu.uoc.epcsd.microcredential.domain.Microcredential;
import edu.uoc.epcsd.microcredential.domain.service.MicrocredentialService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.net.URI;
import java.util.List;

@Log4j2
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController
@RequestMapping("/microcredentials")
public class MicrocredentialRESTController {

    private final MicrocredentialService microcredentialService;

    @PostMapping
    public ResponseEntity<Long> requestMicrocredential(@RequestBody @NotNull @Valid MicrocredentialRequest request) {
        log.trace("requestMicrocredential");
        try {
            Long id = microcredentialService.requestMicrocredential(
                    request.getEnrollmentId(), request.getCourseId(), request.getContent());
            URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(id).toUri();
            return ResponseEntity.created(uri).body(id);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    @GetMapping("/pending")
    @ResponseStatus(HttpStatus.OK)
    public List<Microcredential> getPendingMicrocredentialRequests() {
        log.trace("getPendingMicrocredentialRequests");
        return microcredentialService.getPendingMicrocredentialRequests();
    }

    @GetMapping("/{microcredentialId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Microcredential> getMicrocredentialById(@PathVariable @NotNull Long microcredentialId) {
        log.trace("getMicrocredentialById");
        return microcredentialService.getMicrocredentialById(microcredentialId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{courseId}/create")
    public ResponseEntity<List<Long>> requestCourseMicrocredentials(@PathVariable @NotNull Long courseId) {
        log.trace("requestCourseMicrocredentials");
        try {
            List<Long> ids = microcredentialService.requestCourseMicrocredentials(courseId);
            URI uri = ServletUriComponentsBuilder.fromCurrentRequest().build().toUri();
            return ResponseEntity.created(uri).body(ids);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    @PatchMapping("/{microcredentialId}/approve")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Long> approvePendingMicrocredential(@PathVariable @NotNull Long microcredentialId) {
        log.trace("approvePendingMicrocredential");
        try {
            return ResponseEntity.ok(microcredentialService.approvePendingMicrocredential(microcredentialId));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    @PatchMapping("/{microcredentialId}/reject")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Long> rejectPendingMicrocredential(@PathVariable @NotNull Long microcredentialId) {
        log.trace("rejectPendingMicrocredential");
        try {
            return ResponseEntity.ok(microcredentialService.rejectPendingMicrocredential(microcredentialId));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

}
