package edu.uoc.epcsd.microcredential.application.rest.request;

import lombok.AllArgsConstructor;
import lombok.Getter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Getter
@AllArgsConstructor
public final class MicrocredentialRequest {

    @NotNull
    private final Long enrollmentId;

    @NotNull
    private final Long courseId;

    @NotBlank
    private final String content;

}
