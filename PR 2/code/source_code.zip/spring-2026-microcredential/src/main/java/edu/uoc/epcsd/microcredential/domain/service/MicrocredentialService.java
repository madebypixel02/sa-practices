package edu.uoc.epcsd.microcredential.domain.service;

import edu.uoc.epcsd.microcredential.domain.Microcredential;
import java.util.List;
import java.util.Optional;
import javax.validation.constraints.NotNull;

public interface MicrocredentialService {

    Optional<Microcredential> getMicrocredentialById(@NotNull Long microcredentialId);

    Long requestMicrocredential(Long enrollmentId, Long courseId, String content);

    List<Long> requestCourseMicrocredentials(Long courseId);

    Long approvePendingMicrocredential(Long microcredentialId);

    Long rejectPendingMicrocredential(Long microcredentialId);

    List<Microcredential> getPendingMicrocredentialRequests();

}
